--
-- Database: `profesor`
--

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `capitole`
--

CREATE TABLE `capitole` (
  `id-cap` int(100) NOT NULL,
  `nume-cap` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `capitole`
--

INSERT INTO `capitole` (`id-cap`, `nume-cap`) VALUES
(2, 'Mircea cel Batran si domnitorii Cetatii de Scaun');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `imagini`
--

CREATE TABLE `imagini` (
  `idl` int(100) NOT NULL,
  `idim` int(100) NOT NULL,
  `nume-img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `imagini`
--

INSERT INTO `imagini` (`idl`, `idim`, `nume-img`) VALUES
(2, 1, 'MCB.jpg'),
(2, 2, 'ac_mircea.png'),
(3, 3, 'petru.jpg'),
(3, 4, 'ac_petru.png'),
(4, 5, 'ac_roman.png'),
(4, 6, 'roman.jpg'),
(5, 7, 'ac_stefan.png'),
(6, 9, 'iuga.jpg'),
(7, 10, 'ac_alex.png'),
(7, 11, 'alexandru.jpg'),
(5, 12, 'stefan.jpg');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `imgcapitol`
--

CREATE TABLE `imgcapitol` (
  `idc` int(100) NOT NULL,
  `idim` int(100) NOT NULL,
  `nume-img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `imgcapitol`
--

INSERT INTO `imgcapitol` (`idc`, `idim`, `nume-img`) VALUES
(2, 2, 'mirc.jpg');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `intrebari`
--

CREATE TABLE `intrebari` (
  `id-intreb` int(100) NOT NULL,
  `id-cap` int(100) NOT NULL,
  `intrebare` varchar(200) NOT NULL,
  `tip` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `intrebari`
--

INSERT INTO `intrebari` (`id-intreb`, `id-cap`, `intrebare`, `tip`) VALUES
(2, 2, 'Care au fost principalele confruntari romano-otomane in vremea lui Mircea cel Batran?', 2),
(3, 2, 'Mircea cel Batran a invins la Rovine in anul:', 1),
(4, 2, 'Crestinii au infranti la Nicopole de oastea sultanului.', 1),
(5, 2, 'Aliati ai turcilor in razboaiele cu domnitorii tarilor romane:', 1),
(6, 2, 'Identifica, din text, ce tactica a folosit voievodul in batalia de la Rovine.', 1),
(7, 2, 'A infiintat Mitropolia Moldovei cu sediul la Suceava', 1),
(8, 2, 'Curtea de Arges si Suceava au fost succesiv capitalele Tarii Romanesti', 1),
(9, 2, 'Marea boierime beneficia de dragatorii si de danii de mosie', 1),
(10, 2, 'Mircea cel Batran si Sigismund, regele Ungariei, au semnat un tratat de alianta antiotomana in anul: ', 1),
(11, 2, 'De-a lungul istoriei, Imperiul Otoman a obligat popoarele su[use sa practice credinta otomana.', 1),
(12, 2, 'Cei mai multi dintre voievozii romani au aparat credinta stramoseasca.', 1),
(13, 2, 'In politica interna, Mircea cel Batran a pus bazele principalelor institutii ale statului feudal.A intarit sistemul de aparare prin cetatile:', 2),
(14, 2, 'Petru I Musat a mutat capitala de la:', 1),
(15, 2, 'Fortificatiile Sucevei sunt ridicate in vremea lui:', 1),
(16, 2, 'Semnarea tratatului de la Radom (Polonia) din 1390, intre Mircea cel Batran si Vladislav Iagello s-a realizat cu sprijinul:', 1),
(17, 2, 'Construirea orasului Roman a fost initiata de:', 1),
(18, 2, 'Alexandru I cel Bun ia domnia cu ajutorul lui:', 2),
(19, 2, 'Alexandru este ctitorul a doua mari asezari religioase:', 2),
(20, 2, 'In vremea lui Alexandru I au inceput sa functioneze scoli pe langa manastirile:', 2);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `lectii`
--

CREATE TABLE `lectii` (
  `id-lect` int(100) NOT NULL,
  `id-cap` int(100) NOT NULL,
  `nume-lect` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `lectii`
--

INSERT INTO `lectii` (`id-lect`, `id-cap`, `nume-lect`) VALUES
(2, 2, 'Mircea cel Batran'),
(3, 2, 'Petru I Musat'),
(4, 2, 'Roman I'),
(5, 2, 'Stefan I'),
(6, 2, 'Iuga Ologul'),
(7, 2, 'Alexandru I cel Bun');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `raspunsuri`
--

CREATE TABLE `raspunsuri` (
  `id-rasp` int(100) NOT NULL,
  `id-intreb` int(100) NOT NULL,
  `raspuns` varchar(100) NOT NULL,
  `corect` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `raspunsuri`
--

INSERT INTO `raspunsuri` (`id-rasp`, `id-intreb`, `raspuns`, `corect`) VALUES
(2, 2, 'Rovine', 1),
(3, 2, 'Nicopole', 1),
(4, 2, 'Braila', 0),
(5, 2, 'Cozia', 0),
(6, 3, '1389', 0),
(7, 3, '1395', 1),
(8, 3, '1396', 0),
(9, 4, 'Adevarat', 1),
(10, 4, 'Fals', 0),
(11, 5, 'Sultanul Mahomed al II-lea', 0),
(12, 5, 'Tatarii', 1),
(13, 5, 'Papa', 0),
(14, 5, 'Tarile Romane, Ungaria si Polonia', 0),
(15, 6, 'I-a atras pe turci intr-un loc mlastinos', 1),
(16, 6, 'I-a intampinat pe malul Dunarii ', 0),
(17, 6, 'I-a atras in munti', 0),
(18, 7, 'Basarabii si Musatinii', 0),
(19, 7, 'Alexandru cel Bun', 1),
(20, 7, 'Mircea cel Batran', 0),
(21, 8, 'Adevarat', 0),
(22, 8, 'Fals', 1),
(23, 9, 'Adevarat', 1),
(24, 9, 'Fals', 0),
(25, 10, '1389', 0),
(26, 10, '1418', 0),
(27, 10, '1395', 1),
(28, 11, 'Adevarat', 0),
(29, 11, 'Fals', 1),
(30, 12, 'Adevarat', 1),
(31, 12, 'Fals', 0),
(32, 13, 'Turnu', 1),
(33, 13, 'Giurgiu', 1),
(34, 13, 'Brasov', 0),
(35, 13, 'Targoviste', 0),
(36, 14, 'Siret la Suceava', 1),
(37, 14, 'Iasi la Vaslui', 0),
(38, 14, 'Timisoara la Oradea', 0),
(39, 15, 'Mircea cel Batran', 0),
(40, 15, 'Stefan I', 0),
(41, 15, 'Petru I Musat', 1),
(42, 16, 'Petru I Musat', 1),
(43, 16, 'Roman I', 0),
(44, 16, 'Iuga Ologul', 0),
(45, 16, 'Alexandru I', 0),
(46, 17, 'Petru I Musat', 0),
(47, 17, 'Iuga Ologul', 0),
(48, 17, 'Roman I', 1),
(49, 17, 'Alexandru I', 0),
(50, 18, 'Roman I', 1),
(51, 18, 'Iuga Ologul', 0),
(52, 18, 'Mircea cel Batran', 1),
(53, 18, 'Petru I Musat', 0),
(54, 19, 'Manastirea Bistrita (tinutul Neamtului)', 1),
(55, 19, 'Moldovita', 1),
(56, 19, 'Sucevita', 0),
(57, 19, 'Putna', 0),
(58, 20, 'Radauti', 1),
(59, 20, 'Neamt', 1),
(60, 20, 'Bistrita', 1),
(61, 20, 'Moldovita', 1);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `teste`
--

CREATE TABLE `teste` (
  `id-lect` int(100) NOT NULL,
  `test` varchar(100) NOT NULL,
  `html` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `teste`
--

INSERT INTO `teste` (`id-lect`, `test`, `html`) VALUES
(2, 'harta_1.swf', 'test1.html'),
(2, 'harta_2.swf', 'test2.html'),
(2, 'mircea-plasare.swf', 'test3.html'),
(2, 'test-capete.swf', 'test4.html'),
(3, 'petru.swf', 'test5.html'),
(4, 'roman.swf', 'test6.html'),
(5, 'stefan.swf', 'test7.html'),
(6, 'iuga.swf', 'test8.html'),
(7, 'alexandru.swf', 'test9.html');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `utilizator`
--

CREATE TABLE `utilizator` (
  `id` int(11) NOT NULL,
  `user` varchar(20) NOT NULL,
  `parola` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `utilizator`
--

INSERT INTO `utilizator` (`id`, `user`, `parola`) VALUES
(1, 'profesor', '82b61c54c3e59323575f3cdbd7a35381'),
(2, 'elev', '261ed882507aea177983a79007297dd2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capitole`
--
ALTER TABLE `capitole`
  ADD PRIMARY KEY (`id-cap`);

--
-- Indexes for table `imagini`
--
ALTER TABLE `imagini`
  ADD PRIMARY KEY (`idim`);

--
-- Indexes for table `imgcapitol`
--
ALTER TABLE `imgcapitol`
  ADD PRIMARY KEY (`idim`);

--
-- Indexes for table `intrebari`
--
ALTER TABLE `intrebari`
  ADD PRIMARY KEY (`id-intreb`);

--
-- Indexes for table `lectii`
--
ALTER TABLE `lectii`
  ADD PRIMARY KEY (`id-lect`);

--
-- Indexes for table `raspunsuri`
--
ALTER TABLE `raspunsuri`
  ADD PRIMARY KEY (`id-rasp`);

--
-- Indexes for table `utilizator`
--
ALTER TABLE `utilizator`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `capitole`
--
ALTER TABLE `capitole`
  MODIFY `id-cap` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `imagini`
--
ALTER TABLE `imagini`
  MODIFY `idim` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `imgcapitol`
--
ALTER TABLE `imgcapitol`
  MODIFY `idim` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `intrebari`
--
ALTER TABLE `intrebari`
  MODIFY `id-intreb` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `lectii`
--
ALTER TABLE `lectii`
  MODIFY `id-lect` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `raspunsuri`
--
ALTER TABLE `raspunsuri`
  MODIFY `id-rasp` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
